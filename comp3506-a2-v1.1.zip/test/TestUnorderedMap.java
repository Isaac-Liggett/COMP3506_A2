/**
 * Supplied by the COMP3506/7505 teaching team, Semester 2, 2025.
 */

import uq.comp3506.a2.structures.UnorderedMap;

public class TestUnorderedMap {

    public static void main(String[] args) {
        System.out.println("Testing the UnorderedMap Class...");
     
        UnorderedMap<Integer, String> map = new UnorderedMap<>();
        // Your code here

    }
}
