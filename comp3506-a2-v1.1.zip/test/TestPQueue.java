/**
 * Supplied by the COMP3506/7505 teaching team, Semester 2, 2025.
 */

import uq.comp3506.a2.structures.Heap;

public class TestPQueue {

    public static void main(String[] args) {
        System.out.println("Testing the Heap-based Priority Queue Class...");
     
        Heap<Integer, String> pq = new Heap<>();
        // Your code here

    }
}
